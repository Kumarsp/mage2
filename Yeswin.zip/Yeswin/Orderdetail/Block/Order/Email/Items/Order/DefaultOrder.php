<?php
namespace Yeswin\Orderdetail\Block\Order\Email\Items\Order;

class DefaultOrder extends \Magento\Sales\Block\Order\Email\Items\Order\DefaultOrder
{
    public function setTemplate($template) {
        return parent::setTemplate('Yeswin_Orderdetail::email/items/order/default.phtml');
    }
}


?>