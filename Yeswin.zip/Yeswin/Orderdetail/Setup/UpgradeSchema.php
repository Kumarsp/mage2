<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Yeswin\Orderdetail\Setup;
use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

/**
 * @codeCoverageIgnore
 */
class UpgradeSchema implements UpgradeSchemaInterface
{
    /**
     * {@inheritdoc}
     */
    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;
        $installer->startSetup();
        $tableName = $installer->getTable('sales_order_item');
        if (version_compare($context->getVersion(), '2.0.1', '<')) {
           
            if ($installer->getConnection()->isTableExists($tableName) == true) {
                
                // Declare data

				$columns = [
				
					'activation_key' => [
					
					'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
					
					'nullable' => false,
					
					'length' => 225,
					
					'comment' => 'Product Activation Key',
					
					],
				
				];
				
				$connection = $installer->getConnection();
				
				foreach ($columns as $name => $definition) {
				
					$connection->addColumn($tableName, $name, $definition);
				
				}
            
            }

            $installer->endSetup();
        }
    }
}